# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.9.3] - 2025-08-16

### Added

- Support for:
  - [Frostful](https://modrinth.com/mod/frostiful) and [Schorchful](https://modrinth.com/mod/scorchful).
  - [Tough as Nails](https://modrinth.com/mod/tough-as-nails).
- Now uses [Respackopts](https://modrinth.com/mod/respackopts) for configuration.

## [1.9.2] - 2025-06-25

### Added

- Support for:
  - [Accessories](https://modrinth.com/mod/accessories) and [Accessorify](https://modrinth.com/mod/accessorify).
  - [Minecraft Cursor](https://modrinth.com/mod/minecraft-cursor) based on the hand from Pokémon Ruby, Sapphire and Emerald.
  - [Radical Cobblemon Trainers](https://modrinth.com/mod/rctmod).

### Changed

- Modified `pack.mcmeta` description.

### Removed

- Removed support for [Applied Energistics 2](https://modrinth.com/mod/ae2) and [Applied Energistics 2 Wireless Terminals](https://modrinth.com/mod/applied-energistics-2-wireless-terminals).

## [1.9.1] - 2025-05-05

### Added

- Support for [Raised](https://modrinth.com/mod/raised).

### Changed

- Update mod support for:
  - [Beans Backpacks](https://modrinth.com/mod/beans-backpacks-3) v0.8+.
  - [Create](https://modrinth.com/mod/create) v6.0+ Schematics.

## [1.9.0] - 2025-04-07

### Added

- Support for [Cobblemon: Ride On!](https://modrinth.com/mod/cobblemon-ride-on!).
- Support made by `@xandor4223` on Discord for:
  - [Cobblemon Star Academy](https://www.curseforge.com/minecraft/modpacks/cobblemon-star-academy) modpack.
  - [Cobblemon Rider](https://modrinth.com/mod/cobblemonrider1.5).

## [1.8.0] - 2025-03-27

### Added

- Included Cobblemon Earth Team's resourcepack made by `@_ian` on Discord adding support for:
  - [Daily Shop](https://www.curseforge.com/minecraft/mc-mods/daily-shop)
  - [Echo Chest](https://www.curseforge.com/minecraft/mc-mods/echo-chest)
  - [Iron Chests: Restocked](https://www.curseforge.com/minecraft/mc-mods/ironchests)
  - Let's do [Bakery](https://www.curseforge.com/minecraft/mc-mods/lets-do-bakery-farm-charm-compat), [Brewery](https://www.curseforge.com/minecraft/mc-mods/lets-do-brewery-farm-charm-compat), [Candlelight](https://www.curseforge.com/minecraft/mc-mods/lets-do-candlelight-farm-charm-compat), [Farm and Charm](https://www.curseforge.com/minecraft/mc-mods/lets-do-farm-charm), [Herbal Brews](https://www.curseforge.com/minecraft/mc-mods/lets-do-herbal-brews), [Vinery](https://www.curseforge.com/minecraft/mc-mods/lets-do-vinery)
  - [Numismatic Overhaul](https://www.curseforge.com/minecraft/mc-mods/numismatic-overhaul)
  - [Zenith](https://www.curseforge.com/minecraft/mc-mods/zenith), [Zenith Attributes](https://www.curseforge.com/minecraft/mc-mods/zenith-attributes)

### Changed

- Included Cobblemon Earth Team's resourcepack made by `@_ian` on Discord updating textures for:
  - [Farmer's Delight](https://www.curseforge.com/minecraft/mc-mods/farmers-delight-refabricated)
  - [Supplementaries](https://www.curseforge.com/minecraft/mc-mods/supplementaries)

### Fixed

- Updated [Waystones](https://modrinth.com/mod/waystones) mod gui texture name.


## [1.7.0] - 2025-01-07

### Changed

- Updated Beans Backpacks textures.

### Removed

- Apotheosis and Zenith support.


## [1.6.0] - 2024-12-16

**Minecraft 1.21 Update**

Adapted textures for the changes made in Minecraft 1.21.

### Added

- [Beans Backpacks](https://modrinth.com/mod/beans-backpacks-3) mod compat.

### Fixed

- Updated pack format to 34.


### v1.5.0 - Hotbar Fix - 2024-07-16

Fixed the misalignment on the hotbar icons and added support for [Sawmill](https://modrinth.com/mod/universal-sawmill), [Tierify](https://www.curseforge.com/minecraft/mc-mods/tierify) mods.

**Additions:**
- Support for [Sawmill](https://modrinth.com/mod/universal-sawmill), [Tierify](https://www.curseforge.com/minecraft/mc-mods/tierify) mods;
- Added missing icons from [Farmer's Delight](https://modrinth.com/mod/farmers-delight) and [Farmer's Delight Refabricated](https://modrinth.com/mod/farmers-delight-refabricated).

**Fixes**
- Fixed the misalignment on the hotbar health/armor/mount health/baubles icons from [AppleSkin](https://modrinth.com/mod/appleskin), [Dehydration](https://modrinth.com/mod/dehydration), [Feathers](https://modrinth.com/mod/feathers), [Overflowing Bars](https://modrinth.com/mod/overflowing-bars).


### v1.4.0 - Inventory Tech - 2024-06-13

Added support for a lot of tech and inventory mods requested by people in discord.

**Additions:**
- Support for [Applied Energistics 2](https://modrinth.com/mod/ae2), [AppliedE](https://modrinth.com/mod/appliede), [Applied Energistics 2 Wireless Terminals](https://modrinth.com/mod/applied-energistics-2-wireless-terminals), [ME Requester](https://modrinth.com/mod/merequester) and [ProjectE](https://www.curseforge.com/minecraft/mc-mods/projecte) by @TorchTheDragon (`@torchthedragon` on Discord).
- Support for [Feathers](https://modrinth.com/mod/feathers), [Inventory Sorting](https://modrinth.com/mod/inventory-sorting) and [Scout](https://modrinth.com/mod/scout).

**Fixes**
- [REI](https://modrinth.com/mod/rei) small buttons looking weird.


### v1.3.0 - REI and Traveler's Backpack - 2024-06-05

Added support for [REI](https://modrinth.com/mod/rei) and [Traveler's Backpack](https://modrinth.com/mod/travelersbackpack) mods and updated [Curios API](https://modrinth.com/mod/curios) textures.

**Additions:**
- Support for [Roughly Enough Items (REI)](https://modrinth.com/mod/rei) and [Traveler's Backpack](https://modrinth.com/mod/travelersbackpack) mods.

**Changes**
- Updated [Curios API](https://modrinth.com/mod/curios) support to have a inventory revamp texture.


### v1.2.0 - Inmis and Inventorio - 2024-04-19

Added support for [Inmis](https://modrinth.com/mod/inmis) and [Inventorio](https://modrinth.com/mod/inventorio) mods.

**Additions:**
- Support for [Inmis](https://modrinth.com/mod/inmis) and [Inventorio](https://modrinth.com/mod/inventorio) mods by `@533k` (Seek) on Discord.


### v1.1.0 - More Mods - 2024-04-12

Added support for [Expanded Storage](https://modrinth.com/mod/expanded-storage), [Trinkets](https://modrinth.com/mod/trinkets) and [Iron Furnaces](https://modrinth.com/mod/iron-furnaces) mods.

**Changes**
- Changed vanilla inventory texture to have space for slots added by mods.

**Additions:**
- Support for [Expanded Storage](https://modrinth.com/mod/expanded-storage) and [Trinkets](https://modrinth.com/mod/trinkets) mod;
- Support for [Iron Furnaces](https://modrinth.com/mod/iron-furnaces) mod by `@torchthedragon` on Discord.


### v1.0.0 - Release

Create support and some fixes.

**Additions:**
- Support for [Create](https://modrinth.com/mod/create) and [Create Fabric](https://modrinth.com/mod/create-fabric) mods. By: `@torchthedragon` on Discord.

**Fixes**
- Waystones mod checkbox;
- Tom's Simple Storage mod terminals;
- Sophisticated Core mod gui controls.